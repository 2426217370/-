class Pipe{
    constructor(){
        // 1-向下 0-向上
        this.type = _.random(0,1);

        this.width = 148;
        this.height = _.random(100,game.canvas.height / 2);
        this.x = game.canvas.width;
        this.y = this.type === 0 ? game.canvas.height - this.height - 40 : 0;
        this.speed = 3;
        this.done = false;
    }

    render(){
        // if(game.bird.die){
        //     return;
        // }
        // console.log(this.height);
        if(this.type === 0){//向上
            game.ctx.drawImage(game.images.pipe0,0,0,this.width,this.height,this.x,this.y,this.width,this.height);
        }else if(this.type === 1){//向下
            game.ctx.drawImage(game.images.pipe1,0,1664 - this.height,this.width,this.height,this.x,this.y,this.width,this.height);
        }
    }

    update(){
        this.x -= this.speed;
        // 管道移除
        if(this.x <= -this.width){
            game.pipeArray = _.without(game.pipeArray,this);
        }

        // 和小鸟碰撞
        if(game.bird.x > this.x - game.bird.width && game.bird.x - this.width < this.x){
            // 进入管道的领域
            if(this.type === 0){// 管口向上
                if(game.bird.y + game.bird.height >= this.y){
                    //撞上了
                    game.gamePause();
                }
            }else if(this.type === 1){// 管口向下
                if(game.bird.y <= this.height){
                    //碰撞了
                    game.gamePause();
                }
            }
        }else if(game.bird.y > game.canvas.height - game.bird.height - 48){// 撞地板
            game.gamePause();
        }

        if(!this.done && this.x < game.canvas.width / 2 - this.width){
            console.log("过管");
            game.score.addScore();
            this.done = true;
        }

        // if(!this.done && game.stars.x < game.canvas.width / 2 - game.stars.width){
        //     // if(this.y < game.bird.y && this.y + this.height > game.bird.y && game.bird.x + game.bird.width > this.x){
        //         // if(this.)
        //     console.log("吃到星星");
        //     game.score.addStarsScore();
        //     console.log(game.score.StarsScore);
        //     this.done = true;
        //     // }
        // }
    }

    pause(){
        this.speed = 0;
    }

}