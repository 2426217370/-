class Stars{
    constructor(){
        // this.x = 0;
        // this.y = game.pipe.height;

        this.width = 170;
        this.height = 170;

        this.speed = 3;

        this.num = _.random(1,100);
        // this.x = _.random(game.bird.x + game.bird.width,game.canvas.width);
        this.x = game.canvas.width;
        // this.y = _.random(0,game.canvas.height - game.bird.height - 48);
        this.y = game.pipe.type === 0 ? _.random(0,game.canvas.height - game.pipe.height - 48) : _.random(game.pipe.height,game.canvas.height - 48);

        this.done = false;
    }

    render(){

        // console.log("星星");
        // game.ctx.drawImage(game.images.xingxing,0,0,this.width,this.height,this.x,this.y,this.width - 100,this.height - 100);

        // if(game.pipe.type === 0){
        //     console.log("stars 0");
        // }else if(game.pipe.type === 1){
        //     console.log("stars 1");
        // }
        // console.log(this.y);

        // if(this.x > game.pipe.x && this.x + this.width < game.pipe.x + game.pipe.width){
        //     game.starsArray = _.without(game.starsArray,this);//吃掉星星
        // }

        game.ctx.drawImage(game.images.xingxing,0,0,this.width,this.height,this.x,this.y,this.width - 100,this.height - 100);
        
        

        
        
    }

    update(){
        this.x -= this.speed;

        if(!this.done && (this.x < game.bird.x + game.bird.width / 2) && ((this.y < game.bird.y && this.y + this.height > game.bird.y) || (this.y < game.bird.y + game.bird.height && this.y + this.height > game.bird.y + game.bird.height))){
            console.log("吃到星星");
            game.starsArray = _.without(game.starsArray,this);//吃掉星星
            game.score.addStarsScore();
            console.log(game.score.StarsScore);
            // game.ctx.fillRect(this.x,this.y,this.width - 100,this.height - 100);//清除
            // game.ctx.clearRect(this.x,this.y,this.width - 100,this.height - 100);
            
            
            this.done = true;
        }

        if(this.x <= -this.width){
            game.starsArray = _.without(game.starsArray,this);
        //     // this.x = _.random(game.pipe.x + game.pipe.width,game.canvas.width);
        //     this.y = _.random(0,game.canvas.height - game.bird.height - 48);


            
            
        }
        
        
        
    }

    pause(){
        this.speed = 0;
        // console.log("aa");
    }
}