class Bird{
    constructor(){
        // 单只小鸟的宽度 85
        this.x = (game.canvas.width - 85) / 2;
        this.y = 100;
        this.width = 85;
        this.height = 60;

        // 翅膀的形态 0 1 2
        this.swing = 0;
        this.swingSpeed = 5;

        // 小鸟飞行状态(上升 1，下降 0)
        this.state = 0;
        // 开始下降的帧数
        this.dropStateFrame = game.FrameUtil.currentFrame;
        // 小鸟偏移角度
        this.ro = 0;
        this.dY = 1;

        // 监听鼠标的点击
        this.bindClickListener();
        this.deltaY = 0;

        // 小鸟是否还活着
        this.die = false;

        this.dieAnimateIndex = 0;

    }

    render(){
        if(this.die){
            // 绘制血迹动画
            let row = parseInt(this.dieAnimateIndex / 5);
            let col = this.dieAnimateIndex % 5;

            game.ctx.drawImage(game.images.blood,325 * col,138 * row,325,138,this.x - 150,this.y + 20,325,138);

            if(this.dieAnimateIndex === 30){
                game.gamePause();
            }
            return;
        }


        game.ctx.save();
        game.ctx.translate(this.x + this.width / 2,this.y + this.height / 2);
        game.ctx.rotate(this.ro / 180 * Math.PI);
        game.ctx.translate(-(this.x + this.width / 2),-(this.y + this.height / 2));
        game.ctx.drawImage(game.images.bird,this.swing * this.width,0,this.width,this.height,this.x,this.y,this.width,this.height);
        game.ctx.restore();
        // game.ctx.translate();// 改坐标轴
        // game.ctx.rotate(30 / 180 * Math.PI);// 旋转角度
        // game.ctx.save();// 保存
        // game.ctx.restore();// 恢复
        
    }

    update(){
        if(this.die){
            this.dieAnimateIndex++;
            if(this.dieAnimateIndex === 30){
                // game.gamePause();//就是这
                console.log("是这嘛");
            }
            game.pipeArray = _.without(game.pipeArray,game.pipeArray);//撞地bug
            return true;
        }
        // this.y++;
        // if(this.y === game.canvas.height - 100){
        //     this.y = 100;
        // }
        // 判断小鸟上升和下落的状态
        if(this.state === 0){// 下降
            this.dY = 0.01*Math.pow(game.FrameUtil.currentFrame - this.dropStateFrame,2);
            this.ro+=1;
        }else if(this.state === 1){// 上升
            this.deltaY += 1;
            this.dY = this.deltaY - 15;
            if(this.dY > 0){
                this.state = 0;
                this.dropStateFrame = game.FrameUtil.currentFrame;
            }
        }
        this.y += this.dY;
        // 当前的帧数的5倍来更换一次翅膀
        if(game.FrameUtil.currentFrame % this.swingSpeed === 0){
            this.swing++;
            if(this.swing > 2){
                this.swing = 0;
            }
        }

        // 天空和地板的碰撞检测
        // 和天空的碰撞
        if(this.y < 0){
            this.y = 0;
        }
        // 和地板的碰撞
        // if(this.y >= game.canvas.height - this.height - 48){
        //     // this.y = game.canvas.height - this.height - 48;
            
        //     game.gamePause();
        //     this.x = game.canvas.width;
        // }
   
    }
    // 绑定监听
    bindClickListener(){
        // PC端的鼠标点击事件
        game.canvas.addEventListener("mousedown",()=>{
            this.fly();
        })
        // 兼容移动端的触摸事件
        game.canvas.addEventListener("touchstart",()=>{
            this.fly();
        })
    }
    fly(){
        // 1 改变状态
        this.state = 1;
        // 2 飞行角度
        this.ro = -25;
        // 3 每帧移动的高度向上的高度
        this.deltaY = 1;
        // 4 改变翅膀的速度
        this.swingSpeed = 2;

    }
}