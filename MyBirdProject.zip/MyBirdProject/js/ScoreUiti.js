class ScoreUtil{
    constructor(){
        this.score = 0;
        this.LastScore = 0;
        this.StarsScore = 0;
    }

    // 绘制分数
    render(){
        // 1 绘制分数
        let bit = this.score.toString().length;

        let baseBit = game.canvas.width / 2 - (40 * bit) / 2;
        for(let i=0;i<bit;i++){
            let point = this.score.toString().substr(i,1);
            draw(point,baseBit + i * 40,35);
        }
        
    }

    addScore(){
        this.score++;
        this.LastScore = this.LastScore + 2;
        // console.log(this.score);
    }
    addStarsScore(){
        this.StarsScore++;
        // this.LastScore = this.LastScore + 1;

        this.LastScore = this.LastScore + 1;
    }
}

let draw = (num,x,y)=>{
    game.ctx.drawImage(game.images.number,40 * num,0,40,57,x,y,40,57);
}