class BackGround{
    constructor(params){
        this.image = params.image;
        this.width = params.width;
        this.height = params.height;
        this.x = 0;
        this.y = params.y;

        this.speed = params.speed;

        this.amount = parseInt(game.canvas.width / this.width) + 1;
    }

    // 渲染
    render(){
        // console.log("fangzi");
        for(let i=0;i<this.amount * 2;i++){
            game.ctx.drawImage(this.image,0,0,this.width,this.height,this.x + this.width * i,this.y,this.width,this.height);
        }
    }

    // 走动
    update(){
        this.x -= this.speed;
        if(this.x <= -this.width * this.amount){
            this.x = 0;
        }
    }

    // 暂停
    pause(){
        this.speed = 0;
    }

}