class Game{
    constructor(paramsJson){
        // canvas标签
        this.canvas = document.getElementById(paramsJson.canvasId);
        this.ctx = this.canvas.getContext('2d');
        // 帧工具
        this.FrameUtil = new FrameUtil();
        // fps
        this.fps = this.FrameUtil.realFps || 60;

        // 所有的图片资源
        this.images = null;
        this.score = new ScoreUtil();
        this.sr = new StaticResourceUtil();
        this.sr.loadImages('resource.json',(alreadyLoadNumber,allNum,imageObj)=>{
            // console.log("图片加载完成");
            // console.log(alreadyLoadNumber,allNum,imageObj);
            // 清屏
            this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);

            this.ctx.font = "30px Microsoft YaHei";
            this.ctx.fillText('正在加载的游戏资源:' + alreadyLoadNumber + '/' + allNum,this.canvas.width*0.4,this.canvas.height*0.4);
            if(alreadyLoadNumber === allNum){
                console.log('游戏开始:',imageObj);
                this.images = imageObj;
                this.run();
            }
        })
    }
    /**
     * 运行游戏
     */
    run(){
        // 渲染背景
        // 渲染房子
        this.fz = new BackGround({
            "image":this.images.fangzi,
            "width":300,
            "height":256,
            "y":this.canvas.height - 256 - 40,
            "speed":3
        })
        // 渲染树木
        this.sm = new BackGround({
            "image":this.images.shu,
            "width":300,
            "height":216,
            "y":this.canvas.height - 216 - 40,
            "speed":4
        })
        // 渲染地板
        this.db = new BackGround({
            "image":this.images.diban,
            "width":48,
            "height":48,
            "y":this.canvas.height - 48,
            "speed":4
        })

        // 绘制管道
        this.pipe = new Pipe();
        this.pipeArray = [new Pipe()]

        this.time = setInterval(()=>{
            this.mainLoop();
        },1000/this.fps)

        // 绘制小鸟
        this.bird = new Bird()

        this.gameEnd = false;

        // 绘制星星
        // this.stars = new Stars();
        this.starsArray = [new Stars()];
    }

    /**
     * 主循环
     */
    mainLoop(){
        // 1 调用帧工具
        this.FrameUtil.update();
        // 2 清屏
        this.ctx.clearRect(0,0,this.canvas.clientWidth,this.canvas.clientHeight);
        

        // 4 
        this.fz.render();
        this.fz.update();
        // 5
        this.sm.render();
        this.sm.update();
        //6
        this.db.render();
        this.db.update();

        // 绘制星星
        // this.stars.render();
        // this.stars.update();

        if(this.FrameUtil.currentFrame % 100 === 0){
            let newStars = new Stars();
            this.starsArray.push(newStars);
        }
        for(let i=0;i<this.starsArray.length;i++){
            this.starsArray[i].render();
            this.starsArray[i].update();
        }

        // 7
        if(this.FrameUtil.currentFrame % 100 === 0){
            let newPipe = new Pipe();
            this.pipeArray.push(newPipe);
        }
        // 8 遍历管道数组
        for(let i=0;i<this.pipeArray.length;i++){
            // console.log("pipe");
            this.pipeArray[i].render();
            this.pipeArray[i].update();
        }
        // 9 
        this.bird.render();
        this.bird.update();

        // 10
        this.score.render();

        

        // 3 绘制fps
        this.ctx.font = "16px Microsoft YaHei";
        this.ctx.fillText('FPS /' + this.FrameUtil.realFps,20,20);
        this.ctx.fillText('FNO /' + this.FrameUtil.currentFrame,20,40);

        // 绘制总得分
        // this.score.addScore();
        this.ctx.fillText('星星数：' + this.score.StarsScore,20,60);
        this.ctx.fillText('总得分：' + this.score.LastScore,20,80);

        
    }

    /**
     * 暂停游戏
     */
    gamePause(){
        this.FrameUtil.pause();
        this.fz.pause();
        this.sm.pause();
        this.db.pause();
        for(let i=0;i<this.pipeArray.length;i++){
        //     // console.log("pipe");
            this.gameEnd = true;
            this.bird.die = true;
            this.pipeArray[i].pause();
            // if(this.x <= -this.width){
                game.pipeArray = _.without(game.pipeArray,game.pipeArray);
            // }
            
        }
        // this.stars.pause();
        for(let i=0;i<this.starsArray.length;i++){
            this.starsArray[i].pause();
        }
    }
    

    /**
     * 结束游戏
     */
    gameOver(){

    }
}