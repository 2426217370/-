class FrameUtil{
    constructor(){
        // 1、当前的帧的序号
        this.currentFrame = 0;
        // 2、FPS
        this.realFps = 0;
        // 3、起始帧
        this.sFrame = 0;
        // 4、起始帧对应的时间
        this.sTime = new Date();
    }

    /**
     * 更新帧
     */
    update(){
        // 当前的帧号
        this.currentFrame++;

        // 获取当前帧所在的时间
        let t = new Date();

        // 判断是否到达1秒钟
        if(t-this.sTime >= 1000){
            // 计算fps
            this.realFps = this.currentFrame - this.sFrame;

            //
            this.sFrame = this.currentFrame;
            this.sTime = t;
        }
    }
    
    pause(){
        this.currentFrame = 0;
    }
}