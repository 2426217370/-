class StaticResourceUtil{
    constructor(){
        this.images = {};
    }

    /**
     * 加载图片资源
     */
    loadImages(jsonURL,callback){
        let xhr = new XMLHttpRequest();
        xhr.open('GET',jsonURL,true);
        xhr.send(null);
        xhr.addEventListener('readystatechange',()=>{
            if(xhr.readyState === 4){
                // console.log(xhr.responseText);
                let alreadyLoadNumber = 0;

                let jsonObj = JSON.parse(xhr.responseText);
                console.log(jsonObj);
                for(let i=0;i<jsonObj.images.length;i++){
                    // 实例化出来图片
                    let images = new Image();
                    images.src = jsonObj.images[i].src;
                    // 图片加载完成
                    images.addEventListener('load',()=>{
                        alreadyLoadNumber++;
                        let key = jsonObj.images[i].name;
                        this.images[key] = images;

                        callback && callback(alreadyLoadNumber,jsonObj.images.length,this.images);
                    })
                }
            }
        })
    }
}