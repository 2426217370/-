$(function (){
    $.getJSON('http://localhost:3000/playlist/detail'+location.search,(data)=>{
        console.log(data);
        // console.log(data.playlist.tracks);
        let songList = "";
        let songTitle = "";
        // data.playlist.forEach(title=>{
            // title.name
            document.title = data.playlist.name;
            songTitle=`<div class="pl_bg" style="background-image: url(${data.playlist.coverImgUrl});"></div>
                        <div class="pl_content">
                            <div class="pl_l">
                                <img src="${data.playlist.coverImgUrl}" alt="">
                            </div>
                            <div class="pl_r">
                                <h2>${data.playlist.name}</h2>
                                <a class="play">
                                    <img src="${data.playlist.creator.avatarUrl}">
                                    <p>${data.playlist.creator.nickname}</p>
                                </a>
                            </div>
                        </div>`
        // })
        $(".playlist_header").append(songTitle)

        data.playlist.tracks.forEach((list,id) => {
            let player = "";
            list.ar.forEach(splayer=>{
                // console.log(player.name);
                player+=splayer.name+"/";
            })
            // console.log(player);
            if(player.length>0){
                player=player.substr(0,player.length-1)
            }
            songList+=`<a href="play_song.html?id=${list.id}&alid=${list.al.id}" class="song_list">
                            <div class="song_id">${id+1}</div>
                            <div class="song_list_Nav">
                                <div class="song_list_nav">
                                    <div class="song_title">${list.name}</div>
                                    <div class="song_desc">${player}-${list.al.name}</div>
                                </div>
                                <div class="song_play">

                                </div>
                            </div>
                        </a>`
        });
        $(".songs_list").append(songList);
        // console.log(songList);
    });
    $.getJSON('http://localhost:3000/comment/playlist?id='+location.search.substr(location.search.lastIndexOf('=')+1),data=>{
        console.log(data);
        let commentlist = "";
        let commentsonggo = "";
        data.comments.forEach(comment=>{
            
            console.log(comment.user.nickname);
            commentlist+=`<div class="comments">
                        <div class="cmt_head">
                        <a href="">
                            <img src="${comment.user.avatarUrl}" alt="">
                        </a>
                        </div>
                        <div class="cmt_wrap">
                            <div class="cmt_header">
                                <span>${comment.user.nickname}</span>
                            </div>
                            <div class="cmt_content"><span>${comment.content}</span></div>
                        </div>
                      </div>`
            commentsonggo =`<div class="go"><a href="app.html">>>查看完整榜单<<</a></div>`
        });
        $(".comment").append(commentlist+commentsonggo);
    });
})
