window.onload=$(function (){
    fetch(//最新音乐
        'http://localhost:3000/personalized/newsong?id='+location.search.substr(location.search.lastIndexOf('=')+1),
        {method:'get',mode:'cors'}
    )
    .then((res)=>res.json())
    .then((data)=>{
        console.log(data);
        console.log(location.search.substr(location.search.lastIndexOf('=')+1));
        let id = location.search.substr(location.search.lastIndexOf('=')+1);
        data.result.forEach(song => {
            if(song.id==id){
                console.log(song.name);
                document.title=song.name;
                $("#img_bg>img").attr('src',song.picUrl);
                $("#play_song_bg").attr('src',song.picUrl);
            }
        });
        
    })

    fetch(//hot
        'http://localhost:3000/playlist/detail?id=3778678&'+location.search.substr(location.search.lastIndexOf('&')+1),
        {method:'get',mode:'cors'}
    )
    .then((res)=>res.json())
    .then((data)=>{
        let id = location.search.substr(location.search.lastIndexOf('&')+1);
        let newid = id.substr(4)
        console.log(newid);
        console.log(data);
        data.playlist.tracks.forEach(hot=>{
            if(newid==hot.id){
                console.log(1);
                document.title=hot.name;
                $("#img_bg>img").attr('src',hot.al.picUrl);
                $("#play_song_bg").attr('src',hot.al.picUrl);
            }
        })

        fetch(
            'http://localhost:3000/lyric?id='+newid,
            {method:'get',mode:'cors'}
        )
        .then((res)=>res.json())
        .then((data)=>{
            console.log(data);
            // console.log(data.lrc.lyric);
            let songs_id="";
            
            let lines = data.lrc.lyric.split('\n');
            // let lines = lines.split(']');
            // console.log(lines);
            lines.forEach(arr=>{
                // console.log(arr);
                let Lines = arr.substr(10,arr.length);
                let Lines2 = Lines.split(']')
                let SongTime = arr.substr(0,11)
                // console.log(Lines2);
                // console.log(SongTime);
                // Lines.forEach(Arr=>{
                //     console.log(Arr);
                // })
                songs_id += `<span>${Lines2}</span><br>`
            })
            
            $("#lyric").append(songs_id)
        })
        
    })

    fetch(//search
        'http://localhost:3000/cloudsearch?keywords='+location.search.substr(location.search.lastIndexOf('&')+1),
        {method:'get',mode:'cors'}
    )
    .then((res)=>res.json())
    .then((data)=>{
        console.log(data);
    })

    fetch(//歌单列表
        'http://localhost:3000/album?id='+location.search.substr(location.search.lastIndexOf('=')+1),
        {method:'get',mode:'cors'}
    )
    .then((res)=>res.json())
    .then((data)=>{
        console.log(data);
        console.log(data.songs[0].id);
        var songs_id = data.songs[0].id
        document.title=data.songs[0].name;
        $("#img_bg>img").attr('src',data.album.picUrl)
        $("#play_song_bg").attr('src',data.album.picUrl)
    

        fetch(
            'http://localhost:3000/lyric?id='+songs_id,
            {method:'get',mode:'cors'}
        )
        .then((res)=>res.json())
        .then((data)=>{
            console.log(data);
            // console.log(data.lrc.lyric);
            let songs_id="";
            
            let lines = data.lrc.lyric.split('\n');
            // let lines = lines.split(']');
            console.log(lines);
            lines.forEach(arr=>{
                // console.log(arr);
                let Lines = arr.substr(10,arr.length);
                let Lines2 = Lines.split(']')
                let SongTime = arr.substr(0,11)
                console.log(Lines2);
                // console.log(SongTime);
                // Lines.forEach(Arr=>{
                //     console.log(Arr);
                // })
                songs_id += `<span>${Lines2}</span><br>`
            })
            
            $("#lyric").append(songs_id)
        })
    });
    

    fetch(//歌曲地址
        'http://localhost:3000/song/url'+location.search,
        {method:'get',mode:'cors'}
    )
    .then((res)=>res.json())
    .then((music)=>{
        console.log(music);
        console.log(music.data[0].url);
        $("#music").attr('src',music.data[0].url)
        $("#music").get(0).pause();//返回的jquery对象是数组，所有用get(0)
    });



    $("#music").get(0).onloadedmetadata = function(){
            var rotateVal = 0;//旋转角度
            var InterVal;//定时器
            var img = document.getElementById('img_bg');
            function rotate(){
                InterVal = setInterval(function(){
                    
                    rotateVal +=2;
                    // ProrateVal=rotateVal;
                    // $("#img_bg").attr('style','transform:rotate('+rotateVal+'deg)');
                    // $("#img_bg").attr('style','transition:0.1s linear');
                    img.style.transform = 'rotate('+rotateVal+'deg)';
                    img.style.transition = '0.1s linear';
                    // if(rotateVal>360){
                    //     rotateVal=0;
                    // }
                },100)
            }
        $(".play_turn").click(()=>{
            let music = $("#music").get(0);
            
            function stoprotate(){
                // console.log(ProrateVal);
                // img.style.transform = 'rotate('+ProrateVal+'deg)';
                clearInterval(InterVal);
            }

            if(music.paused){//音频是否暂停
                music.play();
                console.log("play");
                rotate();
                $(".play_turn_after").removeClass("deflection_up").addClass("deflection_down");
                $(".play_btn").attr('style','display:none')
                // $(".img_bg").removeClass("stop").addClass("move");
            }
            else{
                music.pause();
                stoprotate();
                console.log("pause");
                $(".play_turn_after").removeClass("deflection_down").addClass("deflection_up");
                $(".play_btn").attr('style','display:block')
                // $(".img_bg").removeClass("move").addClass("stop");
            }
            
        })
    }
    
})
